// Simple interactive function example
document.addEventListener('DOMContentLoaded', function () {
    console.log('Website loaded!');
});